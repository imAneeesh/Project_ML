# -*- coding: utf-8 -*-
"""
Created on Fri May 19 14:25:32 2023

@author: user
"""

import os
import cv2
import numpy as np
import tensorflow as tf
from sklearn.model_selection import train_test_split

# Define patterns
patterns = ['normal', 'paperpassing', 'peeping', 'signaling']

# Define image size and number of channels
IMG_SIZE = 64
NUM_CHANNELS = 1

# Load images from dataset folder and extract labels and features
data = []
labels = []
for i, pattern in enumerate(patterns):
    pattern_folder = 'dataset/' + pattern
    for filename in os.listdir(pattern_folder):
        img = cv2.imread(pattern_folder + '/' + filename, cv2.IMREAD_GRAYSCALE)
        img = cv2.resize(img, (IMG_SIZE, IMG_SIZE))
        data.append(img)
        labels.append(i)

# Convert data and labels to numpy arrays
data = np.array(data).reshape(-1, IMG_SIZE, IMG_SIZE, NUM_CHANNELS)
labels = np.array(labels)

# Split data into training and testing sets
X_train, X_test, y_train, y_test = train_test_split(data, labels, test_size=0.2, random_state=42)

# Define the CNN model
model = tf.keras.Sequential([
    tf.keras.layers.Conv2D(filters=32, kernel_size=(3, 3), activation='relu', input_shape=(IMG_SIZE, IMG_SIZE, NUM_CHANNELS)),
    tf.keras.layers.MaxPooling2D(pool_size=(2, 2)),
    tf.keras.layers.Conv2D(filters=64, kernel_size=(3, 3), activation='relu'),
    tf.keras.layers.MaxPooling2D(pool_size=(2, 2)),
    tf.keras.layers.Flatten(),
    tf.keras.layers.Dense(units=128, activation='relu'),
    tf.keras.layers.Dense(units=len(patterns), activation='softmax')
])

# Compile the model
model.compile(optimizer='adam', loss='sparse_categorical_crossentropy', metrics=['accuracy'])

# Train the model on the training set
model.fit(X_train, y_train, epochs=10, batch_size=32, validation_data=(X_test, y_test))

# Evaluate the model on the testing set
test_loss, test_acc = model.evaluate(X_test, y_test, verbose=2)
print('Test accuracy:', test_acc)

# Save the model to disk
model.save('cnn_model')

# Load the model from disk
model = tf.keras.models.load_model('cnn_model')

# Define HOG descriptor for detecting people in live video
hog = cv2.HOGDescriptor()
hog.setSVMDetector(cv2.HOGDescriptor_getDefaultPeopleDetector())

# Capture the live video
cap = cv2.VideoCapture(0)

# Define a dictionary to keep track of the number of times each pattern appears
pattern_counts = {}
for pattern in patterns:
    pattern_counts[pattern] = 0

try:
    while True:
        ret, frame = cap.read()

        # Detect people in the frame using HOG descriptor
        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        rects, _ = hog.detectMultiScale(gray, winStride=(4, 4), padding=(4, 4), scale=1.03)

        # Draw rectangles around detected people and classify their actions
        for (x, y, w, h) in rects:
            cv2.rectangle(frame, (x, y), (x + w, y + h), (0, 255, 0), 2)
            roi = gray[y:y + h, x:x + w]
            roi = cv2.resize(roi, (IMG_SIZE, IMG_SIZE))

            # Preprocess the ROI and make a prediction using the CNN model
            roi = np.array(roi).reshape(-1, IMG_SIZE, IMG_SIZE, NUM_CHANNELS)
            roi = roi / 255.0
            prediction = model.predict(roi)
            pattern_index = np.argmax(prediction)
            pattern = patterns[pattern_index]

            # Update the pattern counts dictionary
            pattern_counts[pattern] += 1

            # Display the predicted pattern label on the frame
            font = cv2.FONT_HERSHEY_SIMPLEX
            font_scale = 1
            font_thickness = 2
            text = pattern
            text_size = cv2.getTextSize(text, font, font_scale, font_thickness)[0]
            text_x = x + w // 2 - text_size[0] // 2
            text_y = y + h + text_size[1] + 5
            cv2.putText(frame, text, (text_x, text_y), font, font_scale, (0, 255, 0), font_thickness, cv2.LINE_AA)

        # Display the pattern counts on the frame
        for i, pattern in enumerate(patterns):
            count = pattern_counts[pattern]
            text = f"{pattern}: {count}"
            cv2.putText(frame, text, (10, 30 + 30 * i), cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 255, 0), 2, cv2.LINE_AA)

        # Display the resulting frame
        cv2.imshow('Video', frame)

        # Exit on pressing the 'q' key
        if cv2.waitKey(1) & 0xFF == ord('q'):
            break
finally:
    # Release the capture and destroy all windows
    cap.release()
    cv2.destroyAllWindows()