# -*- coding: utf-8 -*-
"""
Created on Mon May 15 12:46:02 2023

@author: user
"""

# -*- coding: utf-8 -*-
"""
Created on Sun May 14 18:44:33 2023

@author: user
"""

import cv2
import numpy as np
from sklearn.neighbors import KNeighborsClassifier
import os
import pickle
import winsound
from sklearn.model_selection import train_test_split
from sklearn.metrics import confusion_matrix
import matplotlib.pyplot as plt


# Import the necessary libraries.

# Define the patterns that you want to detect.
patterns = ['normal', 'paperpassing', 'peeping', 'signaling']

#patterns = ['normal', 'paperpassing', 'peeping', 'signaling','turningaround','bending']

# Load the images from the dataset folder and extract HOG features.
data = []
labels = []
for i, pattern in enumerate(patterns):
    pattern_folder = 'C:\\Users\\user\\project\\dataset2/' + pattern
    for filename in os.listdir(pattern_folder):
        img = cv2.imread(pattern_folder + '/' + filename, cv2.IMREAD_GRAYSCALE)
        img = cv2.resize(img, (64, 128))
        hog = cv2.HOGDescriptor()
        features = hog.compute(img)
        data.append(features)
        labels.append(i)

# Initialize background subtractor
fgbg = cv2.createBackgroundSubtractorMOG2()

# Initialize person detection model
net = cv2.dnn.readNetFromDarknet('C:\\Users\\user\\project\\yolov3.cfg', 'C:\\Users\\user\\project\\yolov3.weights')
output_layers = net.getUnconnectedOutLayersNames()

# Initialize variables
person_counter = 0
person_locations = {}
        

# Split the data into training and testing sets.
X_train, X_test, y_train, y_test = train_test_split(data, labels, test_size=0.2, random_state=42)

# Train a KNN model on the training set.
knn_model = KNeighborsClassifier(n_neighbors=3)
knn_model.fit(X_train, y_train)

# Predict the labels for the testing set.
y_pred = knn_model.predict(X_test)

# Calculate the overall accuracy and display the confusion matrix.
accuracy = np.mean(y_pred == y_test)
print('Overall Accuracy:', accuracy)
cm = confusion_matrix(y_test, y_pred)
print('Confusion Matrix:')
print(cm)

# Calculate and display the accuracy for each pattern separately.
pattern_accuracy = {}
for pattern in patterns:
    pattern_indices = [i for i, label in enumerate(y_test) if patterns[label] == pattern]
    pattern_accuracy[pattern] = np.mean(np.array(y_pred)[pattern_indices] == np.array(y_test)[pattern_indices])

    print(f'{pattern} Accuracy:', pattern_accuracy[pattern])

# Save the KNN model to disk using pickle.
with open('knn_model.pkl', 'wb') as f:
    pickle.dump(knn_model, f)

# Define HOG descriptor for detecting people in live video.
hog = cv2.HOGDescriptor()
hog.setSVMDetector(cv2.HOGDescriptor_getDefaultPeopleDetector())

# Capture the live video.
cap = cv2.VideoCapture(0)

# Define a dictionary to keep track of the number of times each pattern appears.
pattern_counts = {}
for pattern in patterns:
    pattern_counts[pattern] = 0
    
# Initialize the unique ID for each person.
person_ids = {}

# Initialize an empty dictionary to store the patterns for each ID.
patterns_for_ids = {}


while True:
    ret, frame = cap.read()
    cv2.putText(frame, "Press 'q' to stop", (10, 30), cv2.FONT_HERSHEY_SIMPLEX, 0.9, (0, 0, 255), 1)



    # Apply background subtraction to remove static objects
    fgmask = fgbg.apply(frame)
    
    # Run person detection on the frame
    blob = cv2.dnn.blobFromImage(frame, 1/255.0, (416, 416), swapRB=True, crop=False)
    net.setInput(blob)
    outputs = net.forward(output_layers)
    

    # Extract bounding boxes and confidence scores
    boxes = []
    confidences = []
    for output in outputs:
        for detection in output:
            scores = detection[5:]
            class_id = np.argmax(scores)
            confidence = scores[class_id]
            if confidence > 0.5 and class_id == 0:
                center_x = int(detection[0] * frame.shape[1])
                center_y = int(detection[1] * frame.shape[0])
                width = int(detection[2] * frame.shape[1])
                height = int(detection[3] * frame.shape[0])
                left = int(center_x - width / 2)
                top = int(center_y - height / 2)
                boxes.append([left, top, width, height])
                confidences.append(float(confidence))

    # Apply non-maximum suppression to remove overlapping boxes
    indices = cv2.dnn.NMSBoxes(boxes, confidences, 0.5, 0.4)

    # Loop over detected persons
    for i in indices.flatten():
        # Get bounding box coordinates
        x, y, w, h = boxes[i]

        # Compute the foreground mask for the bounding box
        mask = np.zeros(fgmask.shape, dtype=np.uint8)
        mask[y:y+h, x:x+w] = 255
        fgmask_box = cv2.bitwise_and(fgmask, mask)

        # Compute the density of foreground pixels in the bounding box
        density = np.sum(fgmask_box) / (w * h)

        # Check if the density exceeds a threshold, indicating the presence of a person
        if density > 0.3:
            # Check if the person has been detected before
            person_id = None
            for pid, loc in person_locations.items():
                px, py = loc[-1]
                if x < px < x+w and y < py < y+h:
                    person_id = pid
                    person_locations[pid].append((x+w//2, y+h//2))
                    break

            # If the person hasn't been detected before, assign a new ID
            #if person_id is None:
          # If the person hasn't been detected before, assign a new ID
            if person_id is None:
                person_id = person_counter
                person_locations[person_id] = [(x+w//2, y+h//2)]
                person_counter += 1

    # Draw a bounding box and person ID on the frame
            cv2.rectangle(frame, (x, y), (x+w, y+h), (0, 255, 0), 2)
            cv2.putText(frame, str(person_id), (x, y-5), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 255, 0), 2)

    # Detect people in the frame using HOG descriptor.
    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
    rects, _ = hog.detectMultiScale(gray, winStride=(4, 4), padding=(4, 4), scale=1.03)


    # Draw rectangles around detected people and classify their actions.
    for (x, y, w, h) in rects:
        #cv2.rectangle(frame, (x, y), (x + w, y + h), (0, 255, 0), 2)
        
        # Extract HOG features from the detected person's ROI
        roi = gray[y:y + h, x:x + w]
        roi = cv2.resize(roi, (64, 128))
        roi_hog_fd = hog.compute(roi)
        
        # Use the trained KNN model to predict the action
        nbr = knn_model.predict(np.array([roi_hog_fd], 'float64'))
        predicted_label = patterns[int(nbr)]
        
          
        # Label the person with their unique ID
        cv2.putText(frame, str(person_id), (x, y - 10), cv2.FONT_HERSHEY_SIMPLEX, 0.8, (0, 0, 255))
        print("ID: "+str(person_id))
        
        # Increment the count for the detected pattern for both KNN and SVM
        knn_pattern = patterns[nbr[0]]
        pattern_counts[knn_pattern] += 1
        
        # Draw the predicted action label on the frame for both KNN and SVM
        if pattern_counts[knn_pattern] > 15 and knn_pattern != 'normal':
            cv2.rectangle(frame, (x, y), (x + w, y + h), (0, 0, 255), 2)
            # play beep sound
            #winsound.Beep(frequency, duration)
            if str(person_id) not in patterns_for_ids:
                patterns_for_ids[str(person_id)]=[]
            patterns_for_ids[str(person_id)].append(knn_pattern)

            cv2.putText(frame, knn_pattern+"  ID: "+str(str(person_id)), (x, y - 10), cv2.FONT_HERSHEY_SIMPLEX, 0.9, (0, 0, 255), 2)
        else:
            cv2.putText(frame, knn_pattern+"  ID: "+str(str(person_id)), (x, y - 10), cv2.FONT_HERSHEY_SIMPLEX, 0.9, (0, 255, 0), 2)

       

    # Display the resulting frame
    cv2.imshow('frame', frame)

    # Exit when 'q' is pressed
    if cv2.waitKey(1) & 0xFF == ord('q'):
        # Display the patterns for each ID at the end.

        break
   
for id in patterns_for_ids:
    print(f'ID: {id} - Pattern: {patterns_for_ids[id]}')

for line_name, values in patterns_for_ids.items():
    plt.plot(values, label=line_name,marker='o')

plt.xlabel('Frequency')
plt.ylabel('Abnormal Behaviours')
plt.title('Line Graph')
plt.legend()
plt.show()
cap.release()
cv2.destroyAllWindows()
