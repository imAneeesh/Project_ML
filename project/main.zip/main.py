# -*- coding: utf-8 -*-
"""
Created on Wed Apr 26 13:30:18 2023

@author: ani
"""

import cv2
import numpy as np
from sklearn.neighbors import KNeighborsClassifier
import os
import pickle
import winsound
from sklearn.model_selection import train_test_split
from sklearn.metrics import confusion_matrix

# frequency of the beep sound in Hz
frequency = 2500

# duration of the beep sound in milliseconds
duration = 1000

# Define patterns
patterns = ['normal', 'paperpassing', 'peeping', 'signaling']

# Load images from dataset folder and extract HOG features
data = []
labels = []
for i, pattern in enumerate(patterns):
    pattern_folder = 'C:\\Users\\user\\project\\dataset2/' + pattern
    for filename in os.listdir(pattern_folder):
        img = cv2.imread(pattern_folder + '/' + filename, cv2.IMREAD_GRAYSCALE)
        img = cv2.resize(img, (64, 128))
        hog = cv2.HOGDescriptor()
        features = hog.compute(img)
        data.append(features)
        labels.append(i)
        
        

# Split data into training and testing sets
X_train, X_test, y_train, y_test = train_test_split(data, labels, test_size=0.2, random_state=42)

# Train KNN model on the extracted HOG features
knn_model = KNeighborsClassifier(n_neighbors=3)
knn_model.fit(X_train, y_train)

# Predict labels for the test set
y_pred = knn_model.predict(X_test)

# Calculate overall accuracy and display confusion matrix
accuracy = np.mean(y_pred == y_test)
print('Overall Accuracy:', accuracy)
cm = confusion_matrix(y_test, y_pred)
print('Confusion Matrix:')
print(cm)

# Calculate and display accuracy for each pattern separately
pattern_accuracy = {}
for pattern in patterns:
    pattern_indices = [i for i, label in enumerate(y_test) if patterns[label] == pattern]
    pattern_accuracy[pattern] = np.mean(np.array(y_pred)[pattern_indices] == np.array(y_test)[pattern_indices])

    print(f'{pattern} Accuracy:', pattern_accuracy[pattern])

# Save KNN model to disk using pickle
with open('knn_model.pkl', 'wb') as f:
    pickle.dump(knn_model, f)

# Define HOG descriptor for detecting people in live video
hog = cv2.HOGDescriptor()
hog.setSVMDetector(cv2.HOGDescriptor_getDefaultPeopleDetector())

# Capture the live video
cap = cv2.VideoCapture(0)

# Define a dictionary to keep track of the number of times each pattern appears
pattern_counts = {}
for pattern in patterns:
    pattern_counts[pattern] = 0

while True:
    ret, frame = cap.read()
    cv2.putText(frame, "Press 'q' to stop", (10, 30), cv2.FONT_HERSHEY_SIMPLEX, 0.9, (0, 0, 255), 2)

    # Detect people in the frame using HOG descriptor
    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
    rects, _ = hog.detectMultiScale(gray, winStride=(4, 4), padding=(4, 4), scale=1.03)

    # Draw rectangles around detected people and classify their actions
    for (x, y, w, h) in rects:
        cv2.rectangle(frame, (x, y), (x + w, y + h), (0, 255, 0), 2)
        #winsound.Beep(frequency, duration)
        # Extract HOG features from the detected person's ROI
        roi = gray[y:y + h, x:x + w]
        roi = cv2.resize(roi, (64, 128))
        roi_hog_fd = hog.compute(roi)
        

        # Use the trained KNN model to predict the action
        nbr = knn_model.predict(np.array([roi_hog_fd], 'float64'))
        predicted_label = patterns[int(nbr)]
        
        # Increment the count for the detected pattern for both KNN and SVM
        knn_pattern = patterns[nbr[0]]
        pattern_counts[knn_pattern] += 1
        
        # Draw the predicted action label on the frame for both KNN and SVM
        if pattern_counts[knn_pattern] > 15 and knn_pattern != 'normal':
            cv2.rectangle(frame, (x, y), (x + w, y + h), (0, 0, 255), 2)
            # play beep sound
            winsound.Beep(frequency, duration)
            cv2.putText(frame, knn_pattern, (x, y - 10), cv2.FONT_HERSHEY_SIMPLEX, 0.9, (0, 0, 255), 2)
            # Take a screenshot of the red labeled box
            #timestamp = datetime.datetime.now().strftime('%Y-%m-%d_%H-%M-%S')
            #filename = f'screenshot_{timestamp}.jpg'
            #cv2.imwrite(filename, frame[y:y+h, x:x+w])
        else:
            cv2.putText(frame, knn_pattern, (x, y - 10), cv2.FONT_HERSHEY_SIMPLEX, 0.9, (0, 255, 0), 2)

        # Display the predicted action label above the rectangle
        #cv2.putText(frame, predicted_label, (x, y - 10), cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 0, 255), 2)

    # Display the resulting frame
    cv2.imshow('frame', frame)

    # Exit when 'q' is pressed
    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

cap.release()
cv2.destroyAllWindows()