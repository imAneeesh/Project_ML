from flask import Flask, render_template
import subprocess

app=Flask(__name__,template_folder='templates')

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/about.html')
def about():
    return render_template('about.html')

@app.route('/run')
def hello():
    # Execute your Python script here
    result = subprocess.run(['python', 'C:\\Users\\user\\project\\main.py'], stdout=subprocess.PIPE)
    return result.stdout

if __name__ == '__main__':
    app.run()


